openmeta is a very simple open meta command line utility. 
run it with no arguments to see how you use it. 

Source code is available at http://code.google.com/p/openmeta/

1.0 - initial release
1.0.1 - fixed problem with listing tags
1.0.2 - fixed problem where output was going to stderr, not stdout
1.0.3 - changed name to openmeta


2.0 Nov 11 2013
Changed to OpenMeta / Mavericks tagging. Setting tags will now set tags that both the OS X Finder on 10.9 and OpenMeta apps on 10.7+ can see. 

--Tom Andersen
tom.andersen@gmail.com